package com.example.a3recyclerviewcustomadapterwithheaderandfooter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;

import com.example.a3recyclerviewcustomadapterwithheaderandfooter.adapter.CustomAdapter;
import com.example.a3recyclerviewcustomadapterwithheaderandfooter.model.Member;


import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Context context;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();

        List<Member> members = prepareMemberList();
        refreshAdapter(members);
    }

    private void initViews(){
        recyclerView = findViewById(R.id.recycleView);
        recyclerView.setLayoutManager(new GridLayoutManager(context,1));
    }

    private void refreshAdapter(List<Member> members){
        CustomAdapter adapter = new CustomAdapter(context,members);
        recyclerView.setAdapter(adapter);
    }

    private List<Member> prepareMemberList(){
        List<Member> members = new ArrayList<>();
        members.add(new Member()); // for Header

        for (int i =0; i<30; i++){
            if (i==0||i==5||i==10||i==12){
                members.add(new Member("Rahmatullayev"+i,"Tohir"+i,false));
            }
            else {
                members.add(new Member("Rahmatullayev"+i,"Tohir"+i,true));
            }
        }
        members.add(new Member()); // for Footer
        return members;
    }
}